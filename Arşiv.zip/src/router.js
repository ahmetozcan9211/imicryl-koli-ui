import { createRouter, createWebHistory } from 'vue-router'
import Health from './pages/Health.vue'
import KoliGoruntule from './pages/KoliGoruntule.vue'
import ManuelKoli from './pages/ManuelKoli.vue'
import KoliTransfer from './pages/KoliTransfer.vue'
import SiparistenKoli from "./pages/SiparistenKoli.vue";
import AskidanKoli from "./pages/AskidanKoli.vue";
import LogGoster from "./pages/LogGoster.vue";
import EventGoster from "./pages/EventGoster.vue";



const routes = [
    {
        path: '/',
        redirect: '/health',
    },
    {
        path: '/health',
        name: 'Health',
        component: Health,
        meta: { title: 'Sistem Durumu' },
    },
    {
        path: '/koliler',
        name: 'KoliGoruntule',
        component: KoliGoruntule,
        meta: { title: 'Koli Görüntüleme' },
    },
    {
        path: '/manuel',
        name: 'ManuelKoli',
        component: ManuelKoli,
        meta: { title: 'Manuel Koli Oluşturma' },
    },
    {
        path: '/transfer',
        name: 'KoliTransfer',
        component: KoliTransfer,
        meta: { title: 'Koli Transferi' },
    },
    {
        path: '/siparisten-koli',
        name: 'SiparistenKoli',
        component: SiparistenKoli,
        meta: { title: 'Siparişten Koli' },
    },
    {
        path: '/askidan-koli',
        name: 'AskidanKoli',
        component: AskidanKoli,
        meta: { title: 'Askıdan Koli' },
    },
    {
        path: '/log-goster',
        name: 'LogGoster',
        component: LogGoster,
        meta: { title: 'Log Goster' },
    },
    {
        path: '/event-goster',
        name: 'EventGoster',
        component: EventGoster,
        meta: { title: 'Event Goster' },
    },




    ]

const router = createRouter({
    history: createWebHistory(),
    routes,
})

router.afterEach((to) => {
    document.title = to.meta.title || 'Koli Uygulaması'
})

export default router