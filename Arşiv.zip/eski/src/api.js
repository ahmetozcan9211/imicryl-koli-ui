import axios from 'axios'
const api = axios.create({ baseURL: '/' }) // vite proxy

export default {
    health(){ return api.get('/health') },
    listKoliler(params){ return api.get('/api/koliler', { params }) },
    createKoli(payload){ return api.post('/api/koliler', payload) },
    getKoli(id){ return api.get(`/api/koliler/${id}`) },
    getIcerik(id){ return api.get(`/api/koliler/${id}/icerik`) },
    scan(id, payload){ return api.post(`/api/koliler/${id}/scan`, payload) },
    addSatir(id, payload){ return api.post(`/api/koliler/${id}/satir`, payload) },
    kapat(id, payload){ return api.post(`/api/koliler/${id}/kapat`, payload) },
    setSiparis(id, payload){ return api.post(`/api/koliler/${id}/siparis`, payload) },
    listMalzemeler(params){ return api.get('/api/malzemeler', { params }) },
    createMalzeme(payload){ return api.post('/api/malzemeler', payload) },
    setDurum(id, payload){ return api.post(`/api/koliler/${id}/durum`, payload) },
    get:         (url, cfg)=> api.get(url, cfg),
    post:        (url, data)=> api.post(url, data),
    transfer(payload){ return api.post('/api/transfer', payload) },
    openKoli(payload){ return api.post('/api/koliler/open', payload) },

    getOrderLinesWithBins(siparisNo, params){
        return api.get(`/api/siparis/${encodeURIComponent(siparisNo)}/kalemler_with_bins`, { params })
    },
    updateKoliYer(id, yerkodu){
        return api.patch(`/api/koliler/${id}/yer`, { yerkodu })
    },
    addKoliSatir(koliId, payload){
        return api.post(`/api/koliler/${koliId}/satir`, payload)
    },
    // (istersen toplu ekleme için)
    addKoliSatirBulk(koliId, lines, options = {}){
        return api.post(`/api/koliler/${koliId}/satir/bulk`, { lines, ...options })
    },
    addKoliBulk(id, payload){ return api.post(`/api/koliler/${id}/satir/bulk`, payload) },
    openKoliByOrder(body){
        // body: { siparisno, kolikodu?, depokodu?, aciklama?, olusturan? }
        return api.post('/api/koliler/open_by_order', body)
    },
    moveBetweenKoliler(payload){
        // payload: { kaynakkoliid, hedefkoliid, material, lotno?, serino?, miktar, kullanici?, aciklama? }
        return api.post('/api/move_between_koliler', payload)
    },
    setKoliSiparis(id, siparisno){ return api.patch(`/api/koliler/${id}/siparis`, { siparisno }) },
    clearKoliSiparis(id){ return api.delete(`/api/koliler/${id}/siparis`) },
    getKoliIcerik(id){ return api.get(`/api/koliler/${id}/icerik`) },
    setKoliDurum(id, durum){ return api.post(`/api/koliler/${id}/durum`,
        { durum }) },
    checkStok(payload){ return api.post('/api/stok/uygunluk', payload) },
    deleteKoli(id, { force=false } = {}) { return api.delete(`/api/koliler/${id}`, { data: { force } }) },
    scanToKoli(id, payload){
        return api.post(`/api/koliler/${id}/scan`, payload)
    },
    scanResolve(payload){                 // ✅ yeni helper
        return api.post('/api/scan/resolve', payload)
    },
    transferBulkAtomic(payload){ return api.post('/api/transfer/bulk_atomic', payload) },
}
