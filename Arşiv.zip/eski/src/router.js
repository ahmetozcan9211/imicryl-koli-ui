import { createRouter, createWebHistory } from 'vue-router'
import Home from './views/Home.vue'
import KoliList from './views/KoliList.vue'   // +++
import KoliDetail from './views/KoliDetail.vue'
import Transfer from './views/Transfer.vue'
import SiparisKoli from './views/SiparisKoli.vue'
import ManualKoli from './views/ManualKoli.vue'
import KoliYonet from './views/KoliYonet.vue'

export default createRouter({
    history: createWebHistory(),
    routes: [
        { path: '/', component: Home },
        { path: '/koliler', component: KoliList }, // +++
        { path: '/koli/:id', component: KoliDetail, props: true },
        { path: '/transfer', component: Transfer },
        { path: '/siparis-koli', component: SiparisKoli },
        { path: '/koli-manuel', component: ManualKoli },
        { path: '/koli-yonet', component: KoliYonet },

    ],
})
