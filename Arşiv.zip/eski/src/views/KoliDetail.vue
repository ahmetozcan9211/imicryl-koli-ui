<template>
  <div class="page">
    <!-- Özet Kart -->
    <section class="card header-card" v-if="koli">
      <div class="head-left">
        <div class="id-row">
          <span class="badge">#{{ koli.id }}</span>
          <h2 class="title">{{ koli.kolikodu }}</h2>
          <span class="chip" :class="'chip-' + (koli.durum || 'draft')">{{ koli.durum || 'draft' }}</span>
        </div>

        <div class="meta-row">
          <div class="meta">
            <span class="meta-label">Mühür</span>
            <span class="meta-val">{{ koli.juliandate ?? '-' }}</span>
          </div>
          <div class="meta">
            <span class="meta-label">Oluşma</span>
            <span class="meta-val">{{ fmtDT(koli.olusmats) }}</span>
          </div>
          <div class="meta">
            <span class="meta-label">Kapanış</span>
            <span class="meta-val">{{ fmtDT(koli.kapamats) }}</span>
          </div>
          <div class="meta">
            <span class="meta-label">Depo</span>
            <span class="meta-val">{{ koli.depokodu || '-' }}</span>
          </div>
          <div class="meta">
            <span class="meta-label">Yer</span>
            <span class="meta-val">{{ koli.yerkodu || '-' }}</span>
          </div>
          <div class="meta" v-if="koli.siparisno">
            <span class="meta-label">Sipariş</span>
            <span class="meta-val strong">{{ koli.siparisno }}</span>
          </div>
        </div>
      </div>

      <div class="head-right">
        <div class="field">
          <label>Yer / Raf</label>
          <div class="inline">
            <input v-model="yerInput" placeholder="Örn: RAF-A3" />
            <button class="btn" @click="yerKaydet" :disabled="savingYer">Kaydet</button>
          </div>
          <div class="msg ok" v-if="yerOk">✓ Yer güncellendi</div>
          <div class="msg err" v-if="yerErr">⚠️ {{ yerErr }}</div>
        </div>
      </div>
    </section>

    <div v-else class="loading">Yükleniyor…</div>

    <!-- Sipariş Bağlantısı -->
    <section class="card" v-if="koli">
      <div class="section-head">
        <h3>Sipariş Bağlantısı</h3>
        <div class="muted" v-if="koli.siparisno">Bağlı: <b>{{ koli.siparisno }}</b></div>
        <div class="muted" v-else>Bu koli henüz bir siparişe bağlı değil.</div>
      </div>

      <div class="row wrap">
        <div class="field" style="min-width:240px">
          <label>Sipariş No</label>
          <input v-model="sipInput" placeholder="örn: 00024232" />
        </div>
        <div class="actions">
          <button class="btn primary" @click="saveSiparis" :disabled="savingSip || !sipInput">
            {{ koli?.siparisno ? 'Güncelle' : 'Bağla' }}
          </button>
          <button v-if="koli?.siparisno" class="btn danger" @click="clearSiparis" :disabled="savingSip">
            Bağı Kaldır
          </button>
        </div>
      </div>

      <div class="msg ok" v-if="okMsg">✓ {{ okMsg }}</div>
      <div class="msg err" v-if="errMsg">⚠️ {{ errMsg }}</div>
    </section>

    <!-- İçerik -->
    <section class="card" v-if="koli">
      <div class="section-head">
        <h3>İçerik</h3>
        <button class="btn mini" @click="icerikYukle">↻ Yenile</button>
      </div>

      <div class="table-head">
        <div class="th">Malzeme</div>
        <div class="th">Seçenek</div>
        <div class="th">Lot</div>
        <div class="th">Seri</div>
        <div class="th w130">SKT</div>
        <div class="th w100">Birim</div>
        <div class="th w140 right">Net Miktar</div>
      </div>

      <div class="table-body">
        <div
            v-for="r in icerik"
            :key="r.material + '|' + (r.secenek || '') + '|' + (r.lotno || '') + '|' + (r.serino || '') + '|' + (r.skt || '')"
            class="tr"
        >
          <div class="td"><span class="code">{{ r.material }}</span></div>
          <div class="td">{{ r.secenek || '-' }}</div>
          <div class="td">{{ r.lotno || '-' }}</div>
          <div class="td">{{ r.serino || '-' }}</div>
          <div class="td w130">{{ fmtSKT(r.skt) }}</div>
          <div class="td w100">{{ r.birim }}</div>
          <div class="td w140 right"><strong>{{ r.netmiktar }}</strong></div>
        </div>

        <div v-if="!icerik.length" class="empty">Koli içeriği boş.</div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted, watchEffect } from 'vue'
import { useRoute } from 'vue-router'
import api from '../api'

const route = useRoute()
const id = Number(route.params.id)

// Koli & içerik
const koli = ref(null)
const icerik = ref([])
const loading = ref(true)

// Yer güncelle
const yerInput = ref('')
const savingYer = ref(false)
const yerOk = ref(false)
const yerErr = ref('')

// Sipariş bağlama
const sipInput = ref('')
const savingSip = ref(false)
const okMsg = ref('')
const errMsg = ref('')

// helpers
function fmtDT(ts){
  if (!ts) return '-'
  const d = new Date(ts)
  return isNaN(d.getTime()) ? String(ts) : d.toLocaleString()
}
function fmtSKT(val){
  if(!val) return '-'
  try{
    const d = new Date(val)
    if (isNaN(d)) return String(val)
    return d.toISOString().slice(0,10)
  }catch{ return String(val) }
}

// yükleyiciler
async function load(){
  try{
    loading.value = true
    const { data } = await api.getKoli(id)
    koli.value = data
    yerInput.value = data?.yerkodu || ''
    sipInput.value = data?.siparisno || ''
    await icerikYukle()
  }catch(e){
    console.error(e)
  }finally{
    loading.value = false
  }
}

async function icerikYukle(){
  try{
    const { data } = await api.getKoliIcerik(id)
    icerik.value = data || []
  }catch(e){
    console.error(e)
  }
}

async function yerKaydet(){
  if (!koli.value?.id) return
  try {
    savingYer.value = true
    const { data } = await api.updateKoliYer(koli.value.id, yerInput.value || null)
    koli.value = { ...koli.value, yerkodu: data?.yerkodu || null }
    yerOk.value = true
    setTimeout(()=> yerOk.value = false, 1200)
  } catch (e) {
    yerErr.value = e?.response?.data?.error || e.message
    setTimeout(()=> yerErr.value = '', 2200)
  } finally {
    savingYer.value = false
  }
}

async function saveSiparis(){
  if (!koli.value?.id) return
  try{
    savingSip.value = true
    const { data } = await api.setKoliSiparis(koli.value.id, (sipInput.value || '').trim())
    koli.value = data
    okMsg.value = 'Sipariş atandı'
    setTimeout(()=> okMsg.value='', 1200)
  }catch(e){
    errMsg.value = e?.response?.data?.error || e.message
    setTimeout(()=> errMsg.value='', 2500)
  }finally{
    savingSip.value = false
  }
}

async function clearSiparis(){
  if (!koli.value?.id || !koli.value?.siparisno) return
  const ok = confirm(`Sipariş bağını kaldırmak istiyor musunuz?\n#${koli.value.id} (${koli.value.kolikodu})\nSipariş: ${koli.value.siparisno}`)
  if (!ok) return
  try{
    savingSip.value = true
    const { data } = await api.setKoliSiparis(koli.value.id, null)
    koli.value = data
    sipInput.value = ''
    okMsg.value = 'Sipariş bağı kaldırıldı'
    setTimeout(()=> okMsg.value='', 1200)
  }catch(e){
    errMsg.value = e?.response?.data?.error || e.message
    setTimeout(()=> errMsg.value='', 2500)
  }finally{
    savingSip.value = false
  }
}

onMounted(load)

// detay güncellenince form alanlarını senkron tut
watchEffect(()=> {
  if (koli.value){
    yerInput.value = koli.value.yerkodu || ''
    if (!savingSip.value) sipInput.value = koli.value.siparisno || ''
  }
})
</script>

<style scoped>
.page{ max-width:1100px; margin:24px auto; padding:0 10px }

/* Kart */
.card{
  background:#fff;
  border:1px solid #e5e7eb;
  border-radius:12px;
  padding:14px;
  margin-bottom:14px;
  box-shadow:0 1px 0 rgba(16,24,40,.02);
}

/* Üst başlık */
.header-card{
  display:flex; gap:16px; justify-content:space-between; align-items:flex-start;
}
.head-left{ flex:1 }
.id-row{ display:flex; gap:10px; align-items:center; margin-bottom:8px }
.title{ margin:0; font-size:22px; font-weight:700 }
.badge{ background:#111827; color:#fff; border-radius:8px; padding:4px 8px; font-size:13px }
.chip{
  padding:4px 8px; border-radius:999px; border:1px solid #e5e7eb; font-size:12px; background:#fff;
}
.chip-draft{ background:#eef2ff; border-color:#c7d2fe; color:#3730a3 }
.chip-sealed{ background:#ecfdf5; border-color:#a7f3d0; color:#065f46 }
.chip-shipped{ background:#f0f9ff; border-color:#bae6fd; color:#075985 }
.chip-cancelled{ background:#fef2f2; border-color:#fecaca; color:#7f1d1d }

.meta-row{ display:flex; flex-wrap:wrap; gap:14px }
.meta{ display:flex; gap:6px; align-items:center }
.meta-label{ color:#6b7280; font-size:12px }
.meta-val{ font-weight:600 }
.meta-val.strong{ color:#111827 }

.head-right{ width:320px; max-width:100% }
.inline{ display:flex; gap:8px; align-items:center }

.field{ display:flex; flex-direction:column; gap:6px }
.field > label{ font-size:13px; color:#374151 }
input{
  padding:9px 10px; border:1px solid #e5e7eb; border-radius:10px; outline:none;
}
input:focus{ border-color:#111827; box-shadow:0 0 0 3px rgba(17,24,39,.08) }
.btn{
  border:1px solid #d1d5db; background:#f9fafb; color:#111827;
  padding:8px 12px; border-radius:10px; cursor:pointer; transition:.15s ease;
}
.btn:hover{ transform: translateY(-1px) }
.btn.mini{ padding:6px 10px; border-radius:8px }
.btn.primary{ background:#111827; border-color:#111827; color:#fff }
.btn.danger{ background:#fee2e2; border-color:#fecaca; color:#7f1d1d }

.section-head{ display:flex; align-items:center; justify-content:space-between; margin-bottom:8px }
.row{ display:flex; gap:12px; align-items:flex-end; margin:6px 0 }
.wrap{ flex-wrap:wrap }
.actions{ display:flex; gap:8px; align-items:center }

.msg{ margin-top:8px; font-size:13px }
.msg.ok{ color:#065f46 }
.msg.err{ color:#b00020 }
.muted{ color:#6b7280 }

/* Tablo */
.table-head, .tr{
  display:grid; grid-template-columns: 1.2fr 1fr 1fr 1fr 130px 100px 140px; gap:12px; align-items:center;
}
.table-head{ font-weight:600; color:#374151; padding:6px 8px }
.table-body .tr{
  padding:10px 8px; border-top:1px solid #f1f5f9; transition:.12s ease;
}
.table-body .tr:hover{ background:#fcfcfd }
.td .code{
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
  background:#f3f4f6; border:1px solid #e5e7eb; border-radius:6px; padding:2px 6px; display:inline-block
}
.right{ text-align:right }
.w100{ width:100px }
.w130{ width:130px }
.w140{ width:140px }

.loading{ padding:20px; color:#6b7280 }
.empty{ padding:16px; color:#6b7280; font-size:14px }
</style>