<template>
  <div class="page" :class="{ hasDock: stagedLines.length > 0 }">
    <!-- Sticky üst özet bar -->
    <div class="topbar">
      <div class="left">
        <h2>Manuel Koli Oluşturma Ekranı</h2>
        <div class="sub">Barkod okutarak liste oluştur, <b>Kaydet</b> deyince veritabanına yaz.</div>
      </div>
      <div class="right">
        <div class="chip" :class="stagedLines.length ? 'chip-green' : 'chip-muted'">⏳ Kuyruk: {{ stagedLines.length }}</div>
        <div v-if="koli" class="chip">
          <span class="badge">#{{ koli.id }}</span> {{ koli.kolikodu }}
        </div>
      </div>
    </div>

    <!-- Koli Aç / Yeniden Kullan -->
    <section class="card">
      <div class="row wrap">
        <div class="field">
          <label>Koli Kodu</label>
          <input v-model="form.kolikodu" placeholder="Örn: K-MAN-001" />
        </div>
        <div class="field">
          <label>Depo (ops.)</label>
          <input v-model="form.depokodu" placeholder="Örn: ANA" />
        </div>
        <div class="field">
          <label>Yer/Raf (ops.)</label>
          <input v-model="form.yerkodu" placeholder="Örn: RAF-A3" />
        </div>
        <div class="field grow">
          <label>Açıklama (ops.)</label>
          <input v-model="form.aciklama" placeholder="Not" />
        </div>
        <div class="actions">
          <button class="btn primary" @click="openKoli" :disabled="!form.kolikodu">📦 Aç / Yeniden Kullan</button>
          <button class="btn" @click="$router.push('/koliler')">↩︎ Koli Listesi</button>
        </div>
      </div>

      <p v-if="err" class="msg err">⚠️ {{ err }}</p>
      <div v-if="koli" class="koli-meta">
        <span class="badge">#{{ koli.id }}</span>
        <strong>{{ koli.kolikodu }}</strong>
        <span class="pill">Durum: {{ koli.durum }}</span>
        <span v-if="koli.yerkodu" class="pill">Yer: {{ koli.yerkodu }}</span>
      </div>
    </section>

    <!-- Barkod ile STAGING -->
    <section v-if="koli" class="card">
      <div class="section-head">
        <h3>Barkod Okutularak → Geçici Listeye Ekle</h3>
        <div class="muted tiny">Örnek: <code>(01)869... (10)LOT (17)YYMMDD (99)IMI (240)REF</code></div>
      </div>
      <div class="row wrap">
        <div class="field grow">
          <label>GS1 Barkodu</label>
          <input v-model="barkod" placeholder="(01)...(10)...(17)...(99)...(240)..." @keyup.enter="scanStage" />
        </div>
        <div class="field w120">
          <label>Miktar</label>
          <input v-model.number="scanQty" type="number" min="1" />
        </div>
        <div class="actions">
          <button class="btn primary" @click="scanStage" :disabled="!barkod">➕ Ekle (Staging)</button>
        </div>
      </div>
      <div class="msg ok" v-if="lastScanInfo">✓ Çözümlendi: {{ lastScanInfo }}</div>
      <div v-if="scanErr" class="msg err">⚠️ {{ scanErr }}</div>
      <div class="help">
        <span class="pill">01: GTIN</span>
        <span class="pill">10: Lot</span>
        <span class="pill">17: SKT</span>
        <span class="pill">99: İMI</span>
        <span class="pill">240: Ref</span>
      </div>
    </section>

    <!-- Geçici Liste -->
    <section v-if="koli" class="card">
      <div class="section-head">
        <h3>Kaydedilmemiş Satırlar (Staging)</h3>
        <div class="muted">Toplam {{ stagedLines.length }} satır</div>
      </div>

      <div class="table-head compact">
        <div class="th w40">#</div>
        <div class="th">Malzeme</div>
        <div class="th">Varyant</div>
        <div class="th">Lot</div>
        <div class="th">Seri</div>
        <div class="th w130">SKT</div>
        <div class="th w100">Birim</div>
        <div class="th w140 right">Miktar</div>
        <div class="th w90"></div>
      </div>

      <div class="table-body">
        <div v-if="!stagedLines.length" class="empty">
          Henüz satır yok. Barkod okutun veya alanları düzenleyin, sonra <b>Kaydet</b>.
        </div>
        <div v-for="(ln, i) in stagedLines" :key="i" class="tr compact">
          <div class="td w40">{{ i+1 }}</div>
          <div class="td"><input v-model="ln.material" class="cell-input" /></div>
          <div class="td"><input v-model="ln.secenek" class="cell-input" placeholder="#...#" /></div>
          <div class="td"><input v-model="ln.lotno" class="cell-input" /></div>
          <div class="td"><input v-model="ln.serino" class="cell-input" /></div>
          <div class="td w130"><input v-model="ln.skt" type="date" class="cell-input" /></div>
          <div class="td w100"><input v-model="ln.birim" class="cell-input" /></div>
          <div class="td w140 right"><input v-model.number="ln.miktar" type="number" min="0" class="cell-input right" /></div>
          <div class="td w90"><button class="btn danger mini" @click="removeStage(i)">Sil</button></div>
        </div>
      </div>

      <div class="footer-actions">
        <button class="btn" @click="clearStage" :disabled="!stagedLines.length">🧹 Temizle</button>
        <div class="spacer"></div>
        <label class="muted"><input type="checkbox" v-model="checkStockOnSave" /> Kaydetmeden önce stok kontrolü</label>
        <button class="btn primary" @click="saveAll" :disabled="!stagedLines.length">💾 Kaydet → DB</button>
        <span v-if="saveOk" class="toast ok">✓ Kaydedildi</span>
        <span v-if="saveErr" class="toast err">Hata: {{ saveErr }}</span>
      </div>
    </section>

    <!-- Mevcut İçerik -->
    <section v-if="koli" class="card">
      <div class="section-head">
        <h3>Mevcut İçerik <span class="muted">(#{{ koli.id }})</span></h3>
        <button class="btn mini" @click="icerikYukle">↻ Yenile</button>
      </div>

      <div class="table-head">
        <div class="th">Malzeme</div>
        <div class="th">Varyant</div>
        <div class="th">Lot</div>
        <div class="th">Seri</div>
        <div class="th w130">SKT</div>
        <div class="th w100">Birim</div>
        <div class="th w140 right">Net Miktar</div>
      </div>
      <div class="table-body">
        <div
            v-for="r in icerik"
            :key="r.material + '|' + (r.secenek||'') + '|' + (r.lotno||'') + '|' + (r.serino||'') + '|' + (r.skt||'')"
            class="tr"
        >
          <div class="td"><span class="code">{{ r.material }}</span></div>
          <div class="td">{{ r.secenek || '-' }}</div>
          <div class="td">{{ r.lotno || '-' }}</div>
          <div class="td">{{ r.serino || '-' }}</div>
          <div class="td w130">{{ formatSKT(r.skt) }}</div>
          <div class="td w100">{{ r.birim }}</div>
          <div class="td w140 right"><strong>{{ r.netmiktar }}</strong></div>
        </div>
        <div v-if="!icerik.length" class="empty">Koli içeriği boş.</div>
      </div>
    </section>

    <!-- Alt sabit eylem paneli (yüzen) -->
    <div v-if="stagedLines.length" class="dock">
      <div class="dock-left">⏳ Staging’de <b>{{ stagedLines.length }}</b> satır var</div>
      <div class="dock-right">
        <button class="btn" @click="clearStage">Temizle</button>
        <button class="btn primary" @click="saveAll">Kaydet → DB</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import api from '../api'

// koli meta
const form = ref({ kolikodu:'', depokodu:'', yerkodu:'', aciklama:'' })
const err = ref('')
const koli = ref(null)

// staging
const barkod = ref('')
const scanQty = ref(1)
const stagedLines = ref([])
const scanErr = ref('')
const lastScanInfo = ref('')
const checkStockOnSave = ref(false)
const saveOk = ref(false)
const saveErr = ref('')

// içerik
const icerik = ref([])

function formatSKT(val){ if(!val) return '-'; try{ const d=new Date(val); if(isNaN(d))return val; return d.toISOString().slice(0,10) }catch{return val} }

async function openKoli(){
  err.value = ''
  try {
    const payload = {
      kolikodu: (form.value.kolikodu || '').trim(),
      depokodu: form.value.depokodu || null,
      aciklama: form.value.aciklama || null,
      olusturan: 'ahmet'
    }
    const { data } = await api.openKoli(payload)
    if (form.value.yerkodu) {
      await api.updateKoliYer(data.id, form.value.yerkodu)
      data.yerkodu = form.value.yerkodu
    }
    koli.value = data
    await icerikYukle()
  } catch (e) {
    err.value = e?.response?.data?.error || e.message
  }
}

async function icerikYukle(){
  if(!koli.value) return
  try {
    const { data } = await api.getKoliIcerik(koli.value.id)
    icerik.value = data
  } catch (e) { console.error(e) }
}

function removeStage(i){ stagedLines.value.splice(i,1) }
function clearStage(){ stagedLines.value = [] }

async function scanStage(){
  if(!koli.value || !barkod.value) return
  scanErr.value=''; lastScanInfo.value=''

  try{
    const { data } = await api.scanResolve({ barkod: barkod.value })
    const ln = {
      material: data.resolved.material || '',
      secenek:  data.resolved.secenek || '',
      lotno:    data.parsed.lotno || '',
      serino:   '',
      skt:      data.parsed.skt || null,
      miktar:   Number(scanQty.value) || 1,
      birim:    'ADET'
    }
    stagedLines.value.push(ln)
    lastScanInfo.value = `${ln.material} ${ln.secenek || ''} lot:${ln.lotno || '-'} skt:${ln.skt || '-'}`
    barkod.value=''; scanQty.value=1
  } catch (e) {
    scanErr.value = e?.response?.data?.error || e.message
    setTimeout(()=> scanErr.value='', 2500)
  }
}

async function saveAll(){
  if(!koli.value || !stagedLines.value.length) return
  saveOk.value=false; saveErr.value=''

  try {
    if (checkStockOnSave.value) {
      const group = new Map()
      for (const ln of stagedLines.value) {
        const key = `${(ln.material||'').trim()}||${(ln.lotno||'').trim()}||${(ln.secenek||'').trim()}`
        group.set(key, (group.get(key)||0) + Number(ln.miktar||0))
      }
      for (const [key, want] of group.entries()) {
        const [material, lotno, secenek] = key.split('||')
        await api.checkStok({ material, lotno: lotno || null, secenek: secenek || null, miktar: want })
      }
    }

    await api.post(`/koliler/${koli.value.id}/satir/bulk`, {
      lines: stagedLines.value.map(ln => ({
        material: (ln.material||'').trim(),
        secenek: (ln.secenek||'').trim() || null,
        lotno: (ln.lotno||'').trim() || null,
        serino: (ln.serino||'').trim() || null,
        skt: ln.skt || null,
        miktar: Number(ln.miktar||0),
        birim: (ln.birim||'ADET').trim()
      })),
      autoCreate: true,
      ekleyen: 'ahmet'
    })

    saveOk.value = true
    setTimeout(()=> saveOk.value=false, 1200)
    stagedLines.value = []
    await icerikYukle()
  } catch (e) {
    saveErr.value = e?.response?.data?.message || e?.response?.data?.error || e.message
    setTimeout(()=> saveErr.value='', 3000)
  }
}
</script>

<style scoped>
/* Dock boyu ve sayfa boşluğu */
:root { --dock-h: 64px;
  --dock-btn-bg: #f3f4f6;
  --dock-btn-fg: #111827;
  --dock-btn-pri-bg: #22c55e;   /* yeşil */
  --dock-btn-pri-fg: #fff;}
.page{ max-width:1000px; margin:24px auto; padding:0 8px; }
.page.hasDock{ padding-bottom: calc(var(--dock-h) + 32px); }

/* Sticky üst bar */
.topbar{
  position: sticky; top: 0; z-index: 5;
  background:#ffffffcc; backdrop-filter: blur(6px);
  display:flex; justify-content:space-between; align-items:flex-start;
  border-bottom:1px solid #eef2f7; padding:10px 4px 8px;
}
.topbar h2{ margin:0 0 4px 0; }
.sub{ color:#6b7280; font-size:13px }
.right{ display:flex; gap:8px; align-items:center }

/* Kart ve form alanları */
.card{
  background:#fff; border:1px solid #e5e7eb; border-radius:12px;
  padding:14px; margin:12px 0; box-shadow:0 1px 0 rgba(16,24,40,.02);
}
.row{ display:flex; gap:12px; align-items:flex-end; margin:6px 0 }
.wrap{ flex-wrap:wrap }
.field{ display:flex; flex-direction:column; gap:6px; min-width:220px }
.field.grow{ flex:1 }
.field > label{ font-size:13px; color:#374151 }
.koli-meta{ margin-top:8px; display:flex; gap:8px; align-items:center }

/* Giriş & Butonlar */
input{
  padding:9px 10px; border:1px solid #e5e7eb; border-radius:10px; outline:none;
}
input:focus{ border-color:#111827; box-shadow:0 0 0 3px rgba(17,24,39,.08) }
.btn{
  border:1px solid #d1d5db; background:#f9fafb; color:#111827;
  padding:8px 12px; border-radius:10px; cursor:pointer; transition:.15s ease;
}
.btn:hover{ transform: translateY(-1px) }
.btn:disabled{ opacity:.6; cursor:not-allowed; transform:none }
.btn.primary{ background:#111827; color:#881515; border-color:#111827 }
.btn.mini{ padding:6px 10px; border-radius:8px }
.btn.danger{ background:#fee2e2; border-color:#fecaca; color:#7f1d1d }

/* Chip/Badge/Pill */
.chip{ padding:5px 10px; border-radius:999px; border:1px solid #e5e7eb; background:#fff; font-size:12px }
.chip-muted{ color:#6b7280 }
.chip-green{ background:#ecfdf5; border-color:#a7f3d0; color:#065f46 }
.badge{ display:inline-block; background:#111827; color:#fff; border-radius:6px; padding:2px 6px; font-size:12px }
.pill{
  display:inline-block; background:#f3f4f6; border:1px solid #e5e7eb;
  border-radius:999px; padding:4px 8px; margin-right:6px; font-size:12px; color:#374151;
}

/* Bölüm başlıkları ve mesajlar */
.section-head{ display:flex; justify-content:space-between; align-items:end; gap:8px; margin-bottom:6px }
.help{ margin-top:8px; display:flex; gap:6px; flex-wrap:wrap }
.msg{ margin-top:8px; font-size:13px }
.msg.ok{ color:#065f46 }
.msg.err{ color:#b00020 }

/* Tablo benzeri düzen */
.table-head, .tr{
  display:grid; grid-template-columns: 1fr 1fr 1fr 1fr 130px 100px 140px; gap:12px; align-items:center;
}
.table-head.compact, .tr.compact{
  grid-template-columns: 40px 1fr 1fr 1fr 1fr 130px 100px 140px 90px;
}
.table-head{ font-weight:600; color:#374151; padding:6px 8px }
.table-body .tr{
  padding:10px 8px; border-top:1px solid #f1f5f9; transition:.12s ease;
}
.table-body .tr:hover{ background:#fcfcfd }
.td .code{
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
  background:#f3f4f6; border:1px solid #e5e7eb; border-radius:6px; padding:2px 6px; display:inline-block
}
.cell-input{
  width:100%; padding:7px 8px; border:1px solid #e5e7eb; border-radius:8px;
}
.right{ text-align:right }
.w40{ width:40px }
.w90{ width:90px }
.w100{ width:100px }
.w130{ width:130px }
.w140{ width:140px }
.tiny{ font-size:12px }
.muted{ color:#6b7280 }

/* Footer actions */
.footer-actions{
  display:flex; align-items:center; gap:8px; margin-top:12px;
}
.spacer{ flex:1 }
.toast{ margin-left:8px; font-size:13px }
.toast.ok{ color:#065f46 }
.toast.err{ color:#b00020 }

/* Alt sabit eylem paneli: SAĞ-ALTA YÜZEN */
.dock{
  position: fixed;
  bottom: 16px;
  right: 16px;
  left: auto;                 /* tam genişlik yok */
  height: var(--dock-h);
  min-width: 320px;
  background:#111827; color:#fff;
  display:flex; align-items:center; justify-content:space-between;
  padding:10px 14px;
  border-radius:12px;
  box-shadow: 0 8px 32px rgba(0,0,0,.2);
  z-index: 20;
}
.dock .btn{
  background: var(--dock-btn-bg);
  border-color: var(--dock-btn-bg);
  color: var(--dock-btn-fg);
}
.dock .btn.primary{
  background: var(--dock-btn-pri-bg);
  border-color: var(--dock-btn-pri-bg);
  color: var(--dock-btn-pri-fg);
}
.dock .btn:hover{ filter:brightness(.97) }
.dock .btn.primary:hover{ filter:brightness(.94) }

/* Küçük ekranlarda dock tam genişlik + içeriğe daha fazla alt boşluk */
@media (max-width: 720px){
  .dock{ left:12px; right:12px; bottom:12px; min-width: auto; }
  .page.hasDock{ padding-bottom: calc(var(--dock-h) + 48px); }
}
</style>