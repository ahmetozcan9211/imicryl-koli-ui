<template>
  <div class="wrap">
    <div class="sidebar">
      <div class="side-head">
        <h3>Koliler</h3>
        <div class="filters">
          <input v-model="q" @keyup.enter="loadList" placeholder="Koli/sipariş ara…" />
          <select v-model="durum" @change="loadList">
            <option value="">(Hepsi)</option>
            <option>draft</option><option>sealed</option><option>shipped</option><option>cancelled</option>
          </select>
          <button class="mini" @click="loadList">Ara</button>
        </div>
      </div>

      <div class="list">
        <div
            v-for="k in koliler"
            :key="k.id"
            :class="['item', {active: selectedKoli && selectedKoli.id===k.id}]"
            @click="selectKoli(k.id)"
        >
          <div class="row1">
            <b>#{{ k.id }}</b> • {{ k.kolikodu }}
          </div>
          <div class="row2">
            {{ k.durum }} • {{ k.siparisno || '-' }}
          </div>
          <div class="row3">
            {{ k.yerkodu || '-' }} • {{ new Date(k.olusmats).toLocaleString() }}
          </div>
        </div>
        <div v-if="!koliler.length" class="muted" style="padding:8px">Kayıt bulunamadı</div>
      </div>

      <div class="pager">
        <button class="mini" :disabled="page<=1" @click="page--; loadList()">‹</button>
        <span>Sayfa {{ page }}</span>
        <button class="mini" :disabled="koliler.length < size" @click="page++; loadList()">›</button>
      </div>
    </div>

    <div class="content">
      <div v-if="!selectedKoli" class="empty">Soldan bir koli seçin</div>

      <template v-else>
        <!-- Koli Başlık / Aksiyonlar -->
        <div class="card">
          <div class="headrow">
            <h2>#{{ selectedKoli.id }} — {{ selectedKoli.kolikodu }}</h2>
            <div class="actions">
              <select v-model="selectedKoli.durum" @change="setDurum(selectedKoli.durum)">
                <option>draft</option><option>sealed</option><option>shipped</option><option>cancelled</option>
              </select>
              <input v-model="yerTmp" placeholder="Yer/Raf" style="max-width:160px" />
              <button class="mini" @click="yerKaydet">Yer Kaydet</button>
              <button class="danger mini" @click="silKoli">Koli Sil</button>
            </div>
          </div>
          <div class="muted">
            Sipariş: <b>{{ selectedKoli.siparisno || '-' }}</b> •
            Yer: <b>{{ selectedKoli.yerkodu || '-' }}</b> •
            Durum: <b>{{ selectedKoli.durum }}</b>
          </div>
        </div>

        <!-- Barkod → Staging (DB yazmaz) -->
        <div class="card">
          <h3>Barkod Oku → Geçici Listeye Ekle</h3>
          <div class="row">
            <input v-model="barkod" @keyup.enter="scanStage" placeholder="(01)...(10)...(17)...(99)...(240)..." />
            <input v-model.number="scanQty" type="number" min="1" style="width:120px" />
            <button class="primary" :disabled="!barkod" @click="scanStage">Staging'e Ekle</button>
          </div>
          <div class="muted" v-if="lastScanInfo">Çözümlendi: {{ lastScanInfo }}</div>
          <div class="err" v-if="scanErr">Hata: {{ scanErr }}</div>
        </div>

        <!-- Staging Tablosu -->
        <div class="card">
          <div class="headrow">
            <h3>Kaydedilmemiş Satırlar (Staging)</h3>
            <div class="actions">
              <button class="mini" @click="clearStage" :disabled="!stagedLines.length">Temizle</button>
              <label><input type="checkbox" v-model="checkStockOnSave" /> Kaydetmeden önce stok kontrolü</label>
              <button class="primary" :disabled="!stagedLines.length" @click="saveAll">Kaydet → DB</button>
            </div>
          </div>
          <table class="gridtbl">
            <thead>
            <tr>
              <th>#</th><th>Malzeme</th><th>Varyant</th><th>Lot</th><th>Seri</th><th>SKT</th><th>Birim</th><th style="text-align:right">Miktar</th><th></th>
            </tr>
            </thead>
            <tbody>
            <tr v-if="!stagedLines.length"><td colspan="9" class="muted">Liste boş</td></tr>
            <tr v-for="(ln,i) in stagedLines" :key="i">
              <td>{{ i+1 }}</td>
              <td><input v-model="ln.material" /></td>
              <td><input v-model="ln.secenek" placeholder="#...#" /></td>
              <td><input v-model="ln.lotno" /></td>
              <td><input v-model="ln.serino" /></td>
              <td><input v-model="ln.skt" type="date" /></td>
              <td><input v-model="ln.birim" style="width:80px" /></td>
              <td style="text-align:right"><input v-model.number="ln.miktar" type="number" min="0" style="width:100px;text-align:right" /></td>
              <td><button class="mini" @click="removeStage(i)">Sil</button></td>
            </tr>
            </tbody>
          </table>
          <div v-if="saveOk" class="ok">✓ kaydedildi</div>
          <div v-if="saveErr" class="err">Hata: {{ saveErr }}</div>
        </div>

        <!-- İçerik + Hızlı Transfer/Çıkar -->
        <div class="card">
          <div class="headrow">
            <h3>İçerik</h3>
            <button class="mini" @click="icerikYukle">↻ Yenile</button>
          </div>

          <table class="gridtbl">
            <thead>
            <tr>
              <th>Malzeme</th><th>Varyant</th><th>Lot</th><th>Seri</th><th>SKT</th><th>Birim</th><th style="text-align:right">Net</th><th style="width:280px">Aksiyon</th>
            </tr>
            </thead>
            <tbody>
            <tr v-if="!icerik.length"><td colspan="8" class="muted">Bu kolide içerik yok</td></tr>
            <tr v-for="r in icerik" :key="rowKey(r)">
              <td>{{ r.material }}</td>
              <td>{{ r.secenek || '-' }}</td>
              <td>{{ r.lotno || '-' }}</td>
              <td>{{ r.serino || '-' }}</td>
              <td>{{ formatSKT(r.skt) }}</td>
              <td>{{ r.birim }}</td>
              <td style="text-align:right">{{ r.netmiktar }}</td>
              <td>
                <!-- Çıkar -->
                <input v-model.number="r._out" type="number" min="0" :max="Number(r.netmiktar)" style="width:90px" />
                <button class="mini" @click="cikarSatir(r)" :disabled="!r._out || r._out<=0">Çıkar</button>
                <!-- Transfer -->
                <input v-model.number="r._mv" type="number" min="0" :max="Number(r.netmiktar)" style="width:90px;margin-left:8px" />
                <input v-model="r._target" placeholder="Hedef Koli ID" style="width:110px" />
                <button class="mini" @click="transferEt(r)" :disabled="!r._mv || !r._target">Taşı</button>
              </td>
            </tr>
            </tbody>
          </table>
          <div class="err" v-if="rowErr">{{ rowErr }}</div>
          <div class="ok" v-if="rowOk">{{ rowOk }}</div>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'

// sol liste
const koliler = ref([])
const page = ref(1)
const size = 50
const q = ref('')
const durum = ref('')

// seçili koli + içerik
const selectedKoli = ref(null)
const yerTmp = ref('')
const icerik = ref([])
const rowErr = ref('')
const rowOk = ref('')

// staging
const barkod = ref('')
const scanQty = ref(1)
const stagedLines = ref([])
const scanErr = ref('')
const lastScanInfo = ref('')
const checkStockOnSave = ref(false)
const saveOk = ref(false)
const saveErr = ref('')

function rowKey(r){ return [r.material, r.secenek||'', r.lotno||'', r.serino||'', r.skt||''].join('|') }
function formatSKT(val){ if (!val) return '-'; try{ const d=new Date(val); if(isNaN(d)) return val; return d.toISOString().slice(0,10) }catch{return val} }

async function loadList(){
  const { data } = await api.listKoliler({ q: q.value || undefined, durum: durum.value || undefined, page: page.value, size })
  koliler.value = data || []
}
async function selectKoli(id){
  const { data } = await api.getKoli(id)
  selectedKoli.value = data
  yerTmp.value = data.yerkodu || ''
  await icerikYukle()
}
async function icerikYukle(){
  if(!selectedKoli.value) return
  const { data } = await api.getKoliIcerik(selectedKoli.value.id)
  icerik.value = (data || []).map(x => ({ ...x, _out:null, _mv:null, _target:'' }))
}

async function setDurum(d){
  if(!selectedKoli.value) return
  try {
    const { data } = await api.setKoliDurum(selectedKoli.value.id, d)
    selectedKoli.value = data
  } catch (e) {
    alert(e?.response?.data?.error || e.message)
  }
}
async function yerKaydet(){
  if(!selectedKoli.value) return
  try {
    const { data } = await api.updateKoliYer(selectedKoli.value.id, yerTmp.value || null)
    selectedKoli.value = { ...selectedKoli.value, yerkodu: data.yerkodu || null }
  } catch (e) {
    alert(e?.response?.data?.error || e.message)
  }
}
async function silKoli(){
  if(!selectedKoli.value) return
  if(!confirm('Bu koliyi silmek istiyor musunuz? İçeriği varsa silinemez.')) return
  try{
    await api.deleteKoli(selectedKoli.value.id, { force:false })
    selectedKoli.value = null
    await loadList()
  }catch(e){
    alert(e?.response?.data?.error || e.message)
  }
}

// Barkod → resolve → staging push
async function scanStage(){
  if(!selectedKoli.value || !barkod.value) return
  scanErr.value=''; lastScanInfo.value=''
  try{
    const { data } = await api.scanResolve({ barkod: barkod.value })
    const ln = {
      material: data.resolved.material || '',
      secenek:  data.resolved.secenek || '',
      lotno:    data.parsed.lotno || '',
      serino:   '',
      skt:      data.parsed.skt || null,
      miktar:   Number(scanQty.value) || 1,
      birim:    'ADET'
    }
    stagedLines.value.push(ln)
    lastScanInfo.value = `${ln.material} ${ln.secenek || ''} lot:${ln.lotno || '-'} skt:${ln.skt || '-'}`
    barkod.value=''; scanQty.value=1
  }catch(e){
    scanErr.value = e?.response?.data?.error || e.message
    setTimeout(()=> scanErr.value='', 2500)
  }
}
function removeStage(i){ stagedLines.value.splice(i,1) }
function clearStage(){ stagedLines.value = [] }

async function saveAll(){
  if(!selectedKoli.value || !stagedLines.value.length) return
  saveOk.value=false; saveErr.value=''

  try{
    if (checkStockOnSave.value) {
      // unique (material, lot, secenek) toplu kontrol
      const group = new Map()
      for (const ln of stagedLines.value) {
        const key = `${(ln.material||'').trim()}||${(ln.lotno||'').trim()}||${(ln.secenek||'').trim()}`
        group.set(key, (group.get(key)||0) + Number(ln.miktar||0))
      }
      for (const [key, want] of group.entries()) {
        const [material, lotno, secenek] = key.split('||')
        await api.checkStok({ material, lotno: lotno || null, secenek: secenek || null, miktar: want })
      }
    }

    await api.addKoliBulk(selectedKoli.value.id, {
      lines: stagedLines.value.map(ln => ({
        material: (ln.material||'').trim(),
        secenek:  (ln.secenek||'').trim() || null,
        lotno:    (ln.lotno||'').trim() || null,
        serino:   (ln.serino||'').trim() || null,
        skt:      ln.skt || null,
        miktar:   Number(ln.miktar||0),
        birim:    (ln.birim||'ADET').trim()
      })),
      autoCreate: true,
      ekleyen: 'ahmet'
    })

    saveOk.value = true
    setTimeout(()=> saveOk.value=false, 1200)
    stagedLines.value = []
    await icerikYukle()
  }catch(e){
    saveErr.value = e?.response?.data?.message || e?.response?.data?.error || e.message
    setTimeout(()=> saveErr.value='', 3000)
  }
}

// Çıkar (negatif satır ekleyerek)
async function cikarSatir(r){
  rowErr.value=''; rowOk.value=''
  try{
    await api.post(`/koliler/${selectedKoli.value.id}/cikar`, {
      material: r.material,
      lotno: r.lotno || null,
      serino: r.serino || null,
      secenek: r.secenek || null,
      miktar: Number(r._out),
      birim: r.birim || 'ADET',
      kullanici: 'ahmet'
    })
    rowOk.value = 'Satır çıkarıldı'
    setTimeout(()=> rowOk.value='', 1500)
    await icerikYukle()
  }catch(e){
    rowErr.value = e?.response?.data?.error || e.message
    setTimeout(()=> rowErr.value='', 2500)
  }
}

// Hızlı transfer (hemen uygula) — voptions eşleşmeli
async function transferEt(r){
  rowErr.value=''; rowOk.value=''
  const hedef = Number(r._target)
  const miktar = Number(r._mv)
  if (!hedef || !miktar || miktar<=0) { rowErr.value='Geçersiz hedef/miktar'; return }

  try{
    // secenek/voptions eşleşmesi şartı server fonksiyonunda
    await api.post('/move_between_koliler', {
      kaynakkoliid: selectedKoli.value.id,
      hedefkoliid: hedef,
      material: r.material,
      lotno: r.lotno || null,
      serino: r.serino || null,
      secenek: r.secenek || null,
      miktar: miktar,
      kullanici: 'ahmet',
      aciklama: 'panel transfer'
    })
    rowOk.value = `Taşındı → #${hedef}`
    setTimeout(()=> rowOk.value='', 1500)
    r._mv = null; r._target=''
    await icerikYukle()
  }catch(e){
    rowErr.value = e?.response?.data?.error || e.message
    setTimeout(()=> rowErr.value='', 2500)
  }
}

onMounted(loadList)
</script>

<style scoped>
.wrap{ display:flex; height:calc(100vh - 32px); gap:12px; padding:16px; box-sizing:border-box }
.sidebar{ width:360px; border:1px solid #e5e7eb; border-radius:12px; overflow:hidden; display:flex; flex-direction:column; background:#fff }
.side-head{ padding:12px; border-bottom:1px solid #f1f5f9 }
.filters{ display:flex; gap:6px; }
.filters input, .filters select{ flex:1; padding:6px; border:1px solid #e5e7eb; border-radius:8px }
.list{ flex:1; overflow:auto }
.item{ padding:10px 12px; border-bottom:1px solid #f8fafc; cursor:pointer }
.item.active{ background:#f3f4f6 }
.item .row1{ font-size:14px }
.item .row2, .item .row3{ color:#6b7280; font-size:12px }
.pager{ padding:8px; border-top:1px solid #f1f5f9; display:flex; justify-content:center; gap:8px }
.content{ flex:1; overflow:auto; }
.empty{ color:#6b7280; padding:24px }
.card{ border:1px solid #e5e7eb; border-radius:12px; padding:14px; margin-bottom:12px; background:#fff }
.headrow{ display:flex; justify-content:space-between; align-items:center; gap:12px }
.actions{ display:flex; gap:8px; align-items:center }
.row{ display:flex; gap:8px; align-items:center; margin-top:8px }
.primary{ background:#111827; color:#fff; border:1px solid #111827; border-radius:8px; padding:8px 12px; cursor:pointer }
.mini{ border:1px solid #d1d5db; border-radius:8px; padding:6px 10px; background:#f9fafb; cursor:pointer }
.danger{ border-color:#ef4444; color:#ef4444 }
.gridtbl{ width:100%; border-collapse:collapse }
.gridtbl th, .gridtbl td{ border-bottom:1px solid #f1f5f9; padding:8px; text-align:left }
.muted{ color:#6b7280 }
.ok{ color:#065f46; margin-top:6px }
.err{ color:#b00020; margin-top:6px }
</style>