<template>
  <div class="page">
    <!-- Sticky üst bar -->
    <div class="topbar">
      <div class="left">
        <h2>Siparişten Koli Oluştur</h2>
        <div class="sub">
          Sipariş satırlarından hedef koliyi doldurun. İşlemler Kaydet dediğinizde uygulanır.
        </div>
      </div>
      <div class="right">
        <div class="chip muted" title="Toplam satır">{{ rows.length }} satır</div>
        <div class="chip" :class="stagedMoves.length ? 'chip-green' : 'chip-muted'">
          ⏳ Staging: {{ stagedMoves.length }}
        </div>
      </div>
    </div>

    <!-- Arama alanı -->
    <div class="card">
      <div class="row wrap">
        <div class="field">
          <label>Belge Tipi</label>
          <select v-model="doctype">
            <option value="SIPA">SİPA</option>
            <option value="YSIP">YSIP</option>
          </select>
        </div>
        <div class="field">
          <label>Sipariş No</label>
          <input v-model="siparisNo" placeholder="Örn: 00024232" />
        </div>
        <div class="field">
          <label>Depo (opsiyonel)</label>
          <input v-model="depokodu" placeholder="Örn: 01" />
        </div>
        <div class="actions">
          <button class="btn primary" @click="loadLines" :disabled="!siparisNo || loading">
            <span v-if="!loading">🔎 Satırları getir</span>
            <span v-else class="inline">
              <span class="spinner xs"></span> Yükleniyor
            </span>
          </button>
        </div>
      </div>
      <div class="hint-row" v-if="siparisNo || doctype">
        <span class="pill">Belge: {{ doctype }}</span>
        <span v-if="siparisNo" class="pill">SİPARİŞ: {{ siparisNo }}</span>
        <span v-if="depokodu" class="pill">Depo: {{ depokodu }}</span>
      </div>
      <div v-if="errMsg" class="msg error">⚠️ {{ errMsg }}</div>
    </div>

    <!-- Hedef Koli -->
    <div class="card">
      <div class="row wrap">
        <div class="field">
          <label>Hedef Koli</label>
          <div class="inline">
            <input v-model="hedefKoliKodu" placeholder="Koli Kodu (örn: K-SIPA-001)" />
            <button class="btn" @click="openTargetKoli" :disabled="!hedefKoliKodu || !siparisNo">📦 Aç / Yeniden Kullan</button>
          </div>
          <div v-if="hedefKoli" class="hint">
            <span class="badge">#{{ hedefKoli.id }}</span>
            <strong>{{ hedefKoli.kolikodu }}</strong>
            <span v-if="hedefKoli.yerkodu" class="pill">Yer: {{ hedefKoli.yerkodu }}</span>
          </div>
        </div>
        <div v-if="hedefKoli" class="field">
          <label>Yer Güncelle</label>
          <div class="inline">
            <input v-model="yeniYer" placeholder="RAF-A3 gibi" />
            <button class="btn outline" @click="yerKaydet" :disabled="!yeniYer">💾 Yeri Kaydet</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Yükleniyor iskeleti -->
    <div v-if="loading" class="card">
      <div class="skeleton-group">
        <div class="skeleton title"></div>
        <div class="skeleton row"></div>
        <div class="skeleton row"></div>
        <div class="skeleton row"></div>
      </div>
    </div>

    <!-- Satırlar + Bins -->
    <div v-if="rows.length && !loading" class="card">
      <div class="table-head">
        <div class="th w-220">Kalem</div>
        <div class="th">Ad</div>
        <div class="th w-120 right">İstenen</div>
        <div class="th w-180">Varyant</div>
        <div class="th">Nerede Var? (Koli / Yer / Lot / Miktar)</div>
      </div>

      <div class="table-body">
        <div
            v-for="r in rows"
            :key="r.material + '|' + (r.secenek||'') + '|' + r.lineno"
            class="tr"
        >
          <div class="td w-220">
            <div class="code">{{ r.material }}</div>
            <div class="muted tiny">Kalem: {{ r.lineno ?? '-' }}</div>
          </div>
          <div class="td">{{ r.ad || '-' }}</div>
          <div class="td w-120 right">
            <div><strong>{{ r.qty }}</strong> <span class="muted">{{ r.birim }}</span></div>
          </div>
          <div class="td w-180">
            <span class="pill" v-if="r.secenek">{{ r.secenek }}</span>
            <span v-else class="muted">-</span>
          </div>
          <div class="td">
            <div v-if="!r.bins?.length" class="muted">Bu kalem için stoklanan koli bulunamadı.</div>

            <div
                v-for="b in r.bins"
                :key="b.koliid + '|' + (b.lotno || '') + '|' + (b.serino || '')"
                class="binrow"
            >
              <span class="badge">#{{ b.koliid }}</span>
              <span class="pill">Koli: {{ b.kolikodu }}</span>
              <span class="pill">Yer: {{ b.yerkodu || '-' }}</span>
              <span class="pill">Lot: {{ b.lotno || '-' }}</span>
              <span class="pill qty">{{ b.miktar }} {{ r.birim }}</span>

              <input class="qty-input" type="number" min="0" :max="Number(b.miktar)" v-model.number="b.eklenecek" />
              <button class="btn mini" :disabled="!canAddFromBin(r, b)" @click="stageFromBin(r, b)">
                ➕ Bu koliden ekle
              </button>
              <span v-if="b._ok" class="tag ok">✓ staging</span>
              <span v-if="b._err" class="tag err">Hata: {{ b._err }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- STAGING: Bekleyen İşlemler -->
    <div v-if="rows.length && !loading" class="card">
      <div class="section-head">
        <h3>Bekleyen İşlemler (Staging)</h3>
        <div class="muted">Toplam {{ stagedMoves.length }} transfer</div>
      </div>

      <div class="table-head compact">
        <div class="th">Kaynak Koli</div>
        <div class="th">Malzeme</div>
        <div class="th">Varyant</div>
        <div class="th">Lot</div>
        <div class="th">Seri</div>
        <div class="th right w-120">Miktar</div>
        <div class="th w-100"></div>
      </div>

      <div class="table-body">
        <div v-if="!stagedMoves.length" class="empty">
          Henüz işlem yok. Üstteki <b>“Bu koliden ekle”</b> ile staging’e ekleyin.
        </div>

        <div v-for="(m,i) in stagedMoves" :key="'m'+i" class="tr compact">
          <div class="td">#{{ m.kaynakkoliid }}</div>
          <div class="td"><code>{{ m.material }}</code></div>
          <div class="td">{{ m.secenek || '-' }}</div>
          <div class="td">{{ m.lotno || '-' }}</div>
          <div class="td">{{ m.serino || '-' }}</div>
          <div class="td right w-120">{{ m.miktar }}</div>
          <div class="td w-100"><button class="btn danger mini" @click="unstage(i)">Kaldır</button></div>
        </div>
      </div>

      <div class="footer-actions">
        <button class="btn" @click="clearStaging" :disabled="!stagedMoves.length">🧹 Temizle</button>
        <button class="btn" @click="yenile">↻ Yenile</button>
        <button class="btn outline" @click="$router.push('/koliler')">↩︎ Koli Listesine Dön</button>
        <button class="btn primary" :disabled="!hedefKoli || !stagedMoves.length" @click="saveAll">
          💾 Kaydet → DB
        </button>
        <span v-if="saveOk" class="toast ok">✓ Kaydedildi</span>
        <span v-if="saveErr" class="toast err">Hata: {{ saveErr }}</span>
      </div>
    </div>

    <p v-else-if="!loading" class="muted center">
      Henüz satır yok. Belge tipi ve sipariş no girip <b>Satırları getir</b>.
    </p>

    <!-- Alt sabit eylem çubuğu (staging varsa) -->
    <div v-if="stagedMoves.length" class="dock">
      <div class="dock-left">
        ⏳ Staging’de <b>{{ stagedMoves.length }}</b> transfer var
      </div>
      <div class="dock-right">
        <button class="btn" @click="clearStaging">Temizle</button>
        <button class="btn outline" @click="yenile">Yenile</button>
        <button class="btn primary" :disabled="!hedefKoli" @click="saveAll">Kaydet → DB</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import api from '../api'

const doctype = ref('SIPA')    // ✅ SİPA / YSIP
const siparisNo = ref('')
const depokodu = ref('')
const rows = ref([])
const loading = ref(false)
const errMsg = ref('')

// hedef koli
const hedefKoliKodu = ref('')
const hedefKoli = ref(null)
const yeniYer = ref('')

// staging transferler
const stagedMoves = ref([]) // {kaynakkoliid, hedefkoliid, material, lotno, serino, secenek, miktar, birim, kullanici, aciklama}
const saveOk = ref(false)
const saveErr = ref('')

// sipariş satırlarını bins ile çek
async function loadLines(){
  if(!siparisNo.value) return
  loading.value = true
  errMsg.value = ''
  try {
    const { data } = await api.getOrderLinesWithBins(
        siparisNo.value,
        {
          depokodu: depokodu.value || undefined,
          doctype: doctype.value || undefined   // ✅ eklendi
        }
    )
    rows.value = (data || []).map(r => ({
      ...r,
      bins: (r.bins || []).map(b => ({ ...b, eklenecek: 0 }))
    }))
  } catch(e){
    errMsg.value = e?.response?.data?.error || e.message
    rows.value = []
  } finally {
    loading.value = false
  }
}

async function openTargetKoli(){
  if(!hedefKoliKodu.value || !siparisNo.value) return
  try {
    const { data } = await api.openKoliByOrder({
      doctype: doctype.value || undefined,  // ✅ eklendi
      siparisno: siparisNo.value,
      kolikodu: hedefKoliKodu.value,
      olusturan: 'ahmet'
    })
    hedefKoli.value = data
    yeniYer.value = data?.yerkodu || ''
  } catch(e){
    alert(e?.response?.data?.error || e.message)
  }
}

async function yerKaydet(){
  if(!hedefKoli.value) return
  try {
    const { data } = await api.updateKoliYer(hedefKoli.value.id, yeniYer.value || null)
    hedefKoli.value = { ...hedefKoli.value, yerkodu: data.yerkodu || null }
  } catch(e){
    alert(e?.response?.data?.error || e.message)
  }
}

function canAddFromBin(row, bin){
  if(!hedefKoli.value) return false
  const n = Number(bin.eklenecek)
  return Number.isFinite(n) && n > 0 && n <= Number(bin.miktar)
}

/* 🔄 ANLIK DEĞİŞİM + STAGING: Bu koliden ekle (DB YOK) */
function stageFromBin(row, bin){
  if(!canAddFromBin(row, bin)) return
  try{
    stagedMoves.value.push({
      kaynakkoliid: Number(bin.koliid),
      hedefkoliid: Number(hedefKoli.value.id),
      material: String(row.material).trim(),
      lotno: bin.lotno || null,
      serino: bin.serino || null,
      secenek: row.secenek || null,
      miktar: Number(bin.eklenecek),
      birim: row.birim || 'ADET',
      kullanici: 'ahmet',
      aciklama: `${doctype.value} ${siparisNo.value} staging`
    })
    bin.miktar = Number(bin.miktar) - Number(bin.eklenecek)
    bin._ok = true; bin._err = ''
    bin.eklenecek = 0
    setTimeout(()=> bin._ok = false, 1200)
  } catch(e){
    bin._err = e?.response?.data?.error || e.message
    setTimeout(()=> bin._err = '', 2500)
  }
}

function unstage(i){
  const mv = stagedMoves.value[i]
  if (!mv) return
  for (const r of rows.value){
    if ((r.material||'').trim() !== (mv.material||'').trim()) continue
    if ((r.secenek||'') !== (mv.secenek||'')) continue
    for (const b of (r.bins||[])){
      if (Number(b.koliid)===Number(mv.kaynakkoliid) &&
          (b.lotno||'')===(mv.lotno||'') &&
          (b.serino||'')===(mv.serino||'')) {
        b.miktar = Number(b.miktar) + Number(mv.miktar)
      }
    }
  }
  stagedMoves.value.splice(i,1)
}
function clearStaging(){ stagedMoves.value = [] }

async function saveAll(){
  if(!hedefKoli.value || !stagedMoves.value.length) return
  saveOk.value=false; saveErr.value=''

  try{
    await api.transferBulkAtomic({ transfers: stagedMoves.value })
    saveOk.value = true
    setTimeout(()=> saveOk.value=false, 1200)
    stagedMoves.value = []
    await loadLines()
  }catch(e){
    saveErr.value = e?.response?.data?.message || e?.response?.data?.error || e.message
    setTimeout(()=> saveErr.value='', 3000)
  }
}
function yenile(){ loadLines() }
</script>

<style scoped>
/* Layout */
.page{ max-width:1100px; margin:24px auto; padding:0 8px; }
.topbar{
  position: sticky; top: 0; z-index: 5;
  background: #ffffffcc; backdrop-filter: blur(6px);
  display:flex; justify-content:space-between; align-items:flex-start;
  border-bottom:1px solid #eef2f7; padding:10px 4px 8px;
}
.topbar h2{ margin:0 0 4px 0; }
.sub{ color:#6b7280; font-size:13px }
.right{ display:flex; gap:8px; align-items:center }
.card{
  background:#fff; border:1px solid #e5e7eb; border-radius:12px;
  padding:14px; margin:12px 0;
  box-shadow: 0 1px 0 rgba(16,24,40,.02);
}
.row{ display:flex; gap:12px; align-items:flex-end }
.wrap{ flex-wrap:wrap }
.field{ display:flex; flex-direction:column; gap:6px; min-width:180px }
.field > label{ font-size:13px; color:#374151 }
.inline{ display:flex; gap:8px; align-items:center; }

/* Inputs & Buttons */
input, select{
  padding:9px 10px; border:1px solid #e5e7eb; border-radius:10px;
  outline:none; background:#fff;
}
input:focus, select:focus{ border-color:#111827; box-shadow:0 0 0 3px rgba(17,24,39,.08) }
.btn{
  border:1px solid #d1d5db; background:#f9fafb; color:#111827;
  padding:8px 12px; border-radius:10px; cursor:pointer;
  transition:.15s ease;
}
.btn:hover{ transform: translateY(-1px) }
.btn:disabled{ opacity:.6; cursor:not-allowed; transform:none }
.btn.primary{ background:#111827; color:#fff; border-color:#111827 }
.btn.outline{ background:#fff; border-color:#111827; color:#111827 }
.btn.danger{ background:#fee2e2; border-color:#fecaca; color:#7f1d1d }
.btn.mini{ padding:6px 10px; border-radius:8px }

/* Chips/Badges/Pills */
.hint-row{ margin-top:8px; display:flex; gap:6px; flex-wrap:wrap }
.chip{ padding:5px 10px; border-radius:999px; border:1px solid #e5e7eb; background:#fff; font-size:12px }
.chip-muted{ color:#6b7280 }
.chip-green{ background:#ecfdf5; border-color:#a7f3d0; color:#065f46 }
.badge{ display:inline-block; background:#111827; color:#fff; border-radius:6px; padding:2px 6px; font-size:12px }
.pill{
  display:inline-block; background:#f3f4f6; border:1px solid #e5e7eb;
  border-radius:999px; padding:4px 8px; margin-right:6px; font-size:12px; color:#374151;
}
.pill.qty{ background:#eef2ff; border-color:#c7d2fe }
.hint{ margin-top:6px; display:flex; gap:8px; align-items:center }
.msg.error{ color:#b00020; font-size:13px; margin-top:6px }

/* Spinner & Skeleton */
.spinner{
  width:18px; height:18px; border-radius:50%;
  border:3px solid #e5e7eb; border-top-color:#111827;
  animation: spin 1s linear infinite;
}
.spinner.xs{ width:14px; height:14px; border-width:2px }
@keyframes spin{ to{ transform: rotate(360deg) } }
.skeleton-group{ display:grid; gap:12px }
.skeleton{ background: linear-gradient(90deg, #f3f4f6, #eef2f7, #f3f4f6); background-size:200% 100%; animation: shimmer 1.2s infinite }
.skeleton.title{ height:20px; width:40%; border-radius:8px }
.skeleton.row{ height:14px; width:100%; border-radius:6px }
@keyframes shimmer{ 0%{background-position:200% 0} 100%{background-position:-200% 0} }

/* Table-like layout */
.table-head, .tr{
  display:grid; grid-template-columns: 220px 1fr 120px 180px 1.6fr;
  gap:12px; align-items:center;
}
.table-head{ font-weight:600; color:#374151; padding:6px 8px; }
.table-head.compact, .tr.compact{
  grid-template-columns: 1fr 1fr 1fr 1fr 1fr 120px 100px;
}
.table-body .tr{
  padding:10px 8px; border-top:1px solid #f1f5f9; transition:.12s ease;
}
.table-body .tr:hover{ background:#fcfcfd }
.td .code{ font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace; background:#f3f4f6; border:1px solid #e5e7eb; border-radius:6px; padding:2px 6px; display:inline-block }
.muted{ color:#6b7280 }
.tiny{ font-size:12px }
.right{ text-align:right }
.w-100{ width:100px }
.w-120{ width:120px }
.w-180{ width:180px }
.w-220{ width:220px }

/* Bin row */
.binrow{
  display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin:6px 0;
  padding:8px; border:1px dashed #e5e7eb; border-radius:10px; background:#fafafa;
}
.qty-input{ width:110px; text-align:right; }

/* Section */
.section-head{ display:flex; justify-content:space-between; align-items:center; margin-bottom:8px }

/* Empty & Toasts */
.empty{ color:#6b7280; background:#fafafa; padding:12px; border:1px dashed #e5e7eb; border-radius:10px; margin-top:8px }
.tag{ font-size:12px; margin-left:6px }
.tag.ok{ color:#065f46 }
.tag.err{ color:#991b1b }
.toast{ margin-left:8px; font-size:13px }
.toast.ok{ color:#065f46 }
.toast.err{ color:#b00020 }

/* Bottom dock */
.dock{
  position: fixed; left:0; right:0; bottom:0; z-index:10;
  background:#111827; color:#fff; padding:10px 12px;
  display:flex; align-items:center; justify-content:space-between;
  box-shadow: 0 -10px 30px rgba(0,0,0,.08);
}
.dock .btn{ background:#fff; border-color:#fff }
.center{ text-align:center }
@media (max-width: 960px){
  .table-head, .tr{ grid-template-columns: 180px 1fr 100px 160px 1.4fr }
}
</style>