<template>
  <div class="container">
    <!-- Üst bar -->
    <header class="bar sticky">
      <div class="bar-left">
        <h2>Çoklu Koli Transfer Panosu</h2>
        <span class="muted">Sürükle-bırak ile taslak transfer oluştur, “Kaydet” ile DB’ye yaz.</span>
      </div>
      <router-link to="/koliler" class="link">← Liste</router-link>
    </header>

    <!-- Seçim ve arama -->
    <div class="selector">
      <div class="searchbox">
        <label class="lbl">Koli ara (ID, kod veya sipariş no):</label>
        <div class="search-input">
          <input
              v-model="q"
              placeholder="örn: 1005, K-2025-0001 veya 00024232"
              @input="onSearchInput"
              @keydown.enter.prevent="quickAddFirst"
              @focus="searchOpen = true"
          />
          <button class="mini" @click="yenile" title="Yenile">↻</button>
        </div>
        <small class="hint">Sayı girersen ID’ye, metin girersen kolikodu/duruma/sipariş no’ya göre arar. Enter → ilk sonucu ekler.</small>

        <!-- Arama sonuçları (çoklu seçim) -->
        <div v-if="searchOpen" class="results">
          <div class="results-head">
            <div>Sonuçlar ({{ koliler.length }})</div>
            <div class="actions">
              <label class="muted" style="margin-right:8px">
                Durum:
                <select v-model="durum" @change="onSearchInput">
                  <option value="">(Hepsi)</option>
                  <option>draft</option>
                  <option>sealed</option>
                  <option>shipped</option>
                  <option>cancelled</option>
                </select>
              </label>
              <button class="mini" @click="addAllVisible" :disabled="!koliler.length">+ Görünenlerin tümünü ekle</button>
              <button class="mini outline" @click="searchOpen=false">Kapat</button>
            </div>
          </div>

          <div class="results-body">
            <label v-for="k in koliler" :key="k.id" class="row">
              <input type="checkbox" :checked="seciliIdsSet.has(k.id)" @change="toggleSelect(k.id)" />
              <span class="id">#{{ k.id }}</span>
              <span class="code">{{ k.kolikodu }}</span>

              <!-- ✅ Sipariş no varsa göster -->
              <span v-if="k.siparisno" class="muted sm">SIPA: {{ k.siparisno }}</span>

              <span class="tag" :class="k.durum">{{ k.durum }}</span>
            </label>
            <div v-if="!koliler.length" class="empty">Sonuç yok</div>
          </div>
        </div>
      </div>

      <div class="chips">
        <div class="chip" v-for="id in seciliIds" :key="'chip'+id">
          <span class="strong">#{{ id }}</span>
          <span v-if="getKoli(id)" class="code">
            ({{ getKoli(id).kolikodu }})
            <span v-if="getKoli(id).siparisno" class="muted sm">• SIPA: {{ getKoli(id).siparisno }}</span>
          </span>
          <button class="x" @click="unselect(id)" title="Kaldır">✕</button>
          <button class="x" @click="icerikYukle(id)" title="İçeriği tazele">↻</button>
        </div>

        <div class="pastebox">
          <input
              v-model="bulkText"
              placeholder="ID listesini yapıştır (örn: 101, 102 103)"
              @keydown.enter.prevent="addBulkIds"
          />
          <button class="mini" @click="addBulkIds">+ Ekle</button>
        </div>
      </div>
    </div>

    <div v-if="hata" class="alert">Hata: {{ hata }}</div>

    <!-- Panoda: seçili koliler (base + taslak delta) -->
    <div class="board" v-if="seciliIds.length">
      <section
          v-for="kid in seciliIds"
          :key="'col'+kid"
          class="col"
          @dragover.prevent
          @drop="onDrop(kid)"
      >
        <div class="colhead">
          <div class="title">
            #{{ kid }}
            <span v-if="getKoli(kid)" class="code">
              ({{ getKoli(kid).kolikodu }})
              <span v-if="getKoli(kid)?.siparisno" class="muted sm">• SIPA: {{ getKoli(kid).siparisno }}</span>
            </span>
          </div>
          <div class="col-actions">
            <button class="mini" @click="icerikYukle(kid)" title="Sunucudan tazele">↻</button>
            <button class="mini outline" @click="unselect(kid)" title="Listeden kaldır">✕</button>
          </div>
        </div>

        <div
            v-for="r in displayedRows(kid)"
            :key="keyOf(r)"
            class="card"
            draggable="true"
            @dragstart="onDragStart(kid, r)"
            :title="`${r.material} | Lot:${r.lotno||'-'} Seri:${r.serino||'-'} Miktar:${r.netmiktar}`"
        >
          <div class="mat">{{ r.material }}</div>
          <div class="meta">
            <span class="pill">Lot: {{ r.lotno || '-' }}</span>
            <span class="pill">Seri: {{ r.serino || '-' }}</span>
            <span class="pill" v-if="r.secenek">Var.: {{ r.secenek }}</span>
          </div>
          <div class="qty">Miktar: <b>{{ r.netmiktar }}</b> {{ r.birim }}</div>

          <div
              v-if="deltaBadge(kid, r)"
              class="delta"
              :class="{'pos': deltaVal(kid,r) > 0, 'neg': deltaVal(kid,r) < 0}"
          >
            {{ deltaBadge(kid, r) }}
          </div>
        </div>

        <p v-if="!displayedRows(kid).length" class="muted">İçerik yok.</p>
      </section>
    </div>
    <p v-else class="muted">Arama ile bir veya daha fazla koli seç; ardından sürükle-bırak ile taslak oluştur.</p>

    <!-- Taslak paneli -->
    <section v-if="plan.length" class="staged">
      <div class="staged-head">
        <h3>Taslak Transferler</h3>
        <div class="actions">
          <button class="mini danger" @click="clearPlan">Temizle</button>
          <button class="mini primary" @click="savePlan">Kaydet</button>
        </div>
      </div>
      <table class="grid">
        <thead>
        <tr>
          <th>Kaynak</th><th>Hedef</th><th>Material</th><th>Lot</th><th>Seri</th>
          <th style="text-align:right">Miktar</th><th>Birim</th><th></th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="p in plan" :key="p.key">
          <td>#{{p.fromId}} <span v-if="getKoli(p.fromId)" class="code">({{getKoli(p.fromId).kolikodu}})</span></td>
          <td>#{{p.toId}} <span v-if="getKoli(p.toId)" class="code">({{getKoli(p.toId).kolikodu}})</span></td>
          <td>{{p.material}}</td>
          <td>{{p.lotno || '-'}}</td>
          <td>{{p.serino || '-'}}</td>
          <td style="text-align:right">{{p.qty}}</td>
          <td>{{p.birim}}</td>
          <td><button class="mini" @click="removePlan(p)">Sil</button></td>
        </tr>
        </tbody>
      </table>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, computed, watch } from 'vue'
import api from '../api'
import { io } from 'socket.io-client'

/** Socket (diğer oturumlar değişince tazelemek için) */
const socket = io('http://localhost:8080', { transports: ['websocket'], autoConnect: true })

/** STATE */
const koliler = ref([])         // arama sonuçları
const durum = ref('')           // arama filtresi
const q = ref('')               // arama metni
let debounceT = null
const searchOpen = ref(false)

const seciliIds = ref([])       // görünür kolonlar
const seciliIdsSet = computed(() => new Set(seciliIds.value))
const bulkText = ref('')

const icerikMap = ref({})       // { koliid: IcerikSatir[] }
const plan = ref([])            // {fromId,toId,material,lotno,serino,qty,birim,key}
const dragging = ref(null)
const hata = ref('')

/** HELPERS */
function keyOf(r){
  return `${r.material}|${r.lotno||''}|${r.serino||''}|${(r.secenek||'').toLowerCase()}`
}
function rowKey(r){ return keyOf(r) }
function getKoli(id){ return koliler.value.find(k => k.id === id) || cachedKoliMeta[id] || null }

/** Kolilerin meta’sını seçince kaybediyoruz; chip’te göstermek için cache tutalım */
const cachedKoliMeta = {}
watch(koliler, (rows) => {
  for (const k of rows) cachedKoliMeta[k.id] = k
}, { deep:true })

/** Taslak delta haritası */
const stagedDeltas = computed(() => {
  const map = {}
  for (const p of plan.value) {
    const src = (map[p.fromId] ||= {})
    const dst = (map[p.toId]   ||= {})
    const k = `${p.material}|${p.lotno||''}|${p.serino||''}|${(p.secenek||'').toLowerCase()}`
    src[k] = (src[k] || 0) - Number(p.qty)
    dst[k] = (dst[k] || 0) + Number(p.qty)
  }
  return map
})

/** Görünüm: base + delta, 0 altı gizli */
function displayedRows(kid){
  const base = (icerikMap.value[kid] || [])
  const deltas = stagedDeltas.value[kid] || {}

  const map = new Map()
  for (const r of base) map.set(keyOf(r), { ...r, netmiktar: Number(r.netmiktar) })

  for (const [k, d] of Object.entries(deltas)) {
    const [material, lotno='', serino='', secenek=''] = k.split('|')
    const row = map.get(k)
    if (row) {
      row.netmiktar = Number(row.netmiktar) + Number(d)
    } else if (d > 0) {
      map.set(k, {
        koliid: kid,
        kolikodu: getKoli(kid)?.kolikodu || '',
        material,
        lotno: lotno || null,
        serino: serino || null,
        secenek: secenek || '',   // 🔹 yeni
        netmiktar: Number(d),
        birim: 'ADET'
      })
    }
  }

  const rows = [...map.values()].filter(r => Number(r.netmiktar) > 0)
  rows.sort((a,b) => (a.material+b.lotno+b.serino).localeCompare(b.material+b.lotno+b.serino))
  return rows
}
function deltaVal(kid, r){
  const d = (stagedDeltas.value[kid] || {})[rowKey(r)] || 0
  return d
}
function deltaBadge(kid, r){
  const d = deltaVal(kid, r)
  if (!d) return ''
  return d > 0 ? `+${d} (taslak)` : `${d} (taslak)`
}

/** LOADERS */
async function loadKoliler(){
  try {
    const params = { size: 100, durum: durum.value || undefined }
    if (q.value?.trim()) params.q = q.value.trim()
    const { data } = await api.listKoliler(params) // beklenen: id, kolikodu, durum, olusmats, siparisno
    koliler.value = data || []
    searchOpen.value = true
  } catch (e) {
    hata.value = e?.response?.data?.error || e?.message
  }
}
function onSearchInput(){
  clearTimeout(debounceT)
  debounceT = setTimeout(loadKoliler, 300)
}
function quickAddFirst(){
  if (!koliler.value.length) return
  const first = koliler.value[0]
  toggleSelect(first.id, true)
}
function toggleSelect(id, forceAdd = null){
  const exists = seciliIds.value.includes(id)
  if ((forceAdd === true && exists) || (forceAdd === false && !exists)) return
  if (exists) {
    seciliIds.value = seciliIds.value.filter(x => x !== id)
    delete icerikMap.value[id]
  } else {
    seciliIds.value.push(id)
    icerikYukle(id)
  }
}
function addAllVisible(){
  for (const k of koliler.value) toggleSelect(k.id, true)
}
function unselect(id){
  seciliIds.value = seciliIds.value.filter(x => x !== id)
  delete icerikMap.value[id]
}
function addBulkIds(){
  const ids = (bulkText.value || '')
      .split(/[\s,;]+/)
      .map(s => Number(s))
      .filter(n => Number.isFinite(n))
  for (const id of ids) toggleSelect(id, true)
  bulkText.value = ''
}

async function loadSeciliIcerikler(){
  if (seciliIds.value.length === 0) { icerikMap.value = {}; return }
  try {
    const idsParam = seciliIds.value.join(',')
    // Mevcut projendeki API tabanı korunuyor:
    const { data } = await api.get('/api/koliler/icerik', { params: { ids: idsParam }})
    icerikMap.value = data || {}
  } catch (e) {
    // fallback: tek tek çek
    const map = {}
    for (const id of seciliIds.value) {
      try {
        const { data } = await api.getIcerik(id)
        map[id] = data
      } catch (e2) {}
    }
    icerikMap.value = map
  }
}
async function icerikYukle(id){
  try {
    const { data } = await api.getIcerik(id)
    icerikMap.value = { ...icerikMap.value, [id]: data || [] }
  } catch (e) {
    alert(e?.response?.data?.error || e?.message)
  }
}
async function yenile(){
  await loadKoliler()
  await loadSeciliIcerikler()
}

/** DnD & Taslak */
function onDragStart(fromId, row){
  dragging.value = { fromId, row }
}
function onDrop(toId){
  if(!dragging.value) return
  const { fromId, row } = dragging.value
  dragging.value = null
  if (fromId === toId) return

  const baseQty = Number(row.netmiktar)
  const d = (stagedDeltas.value[fromId] || {})[rowKey(row)] || 0
  const remain = baseQty + d
  if (remain <= 0) { alert('Bu satır için planlanabilir miktar kalmadı.'); return }

  const qty = Number(prompt(`Transfer miktarı? (kalan: ${remain})`, '1'))
  if(!qty || qty <= 0) return
  if(qty > remain){ alert('Girilen miktar kalan planlanabilir miktardan büyük.'); return }

  plan.value.push({
    fromId, toId,
    material: row.material,
    lotno: row.lotno || null,
    serino: row.serino || null,
    secenek: row.secenek || null,   // 🔹 yeni
    qty,
    birim: row.birim,
    key: `${fromId}->${toId}|${rowKey(row)}|${Date.now()}`
  })
}
function removePlan(item){
  plan.value = plan.value.filter(p => p !== item)
}
function clearPlan(){ plan.value = [] }

async function savePlan(){
  if (!plan.value.length) return
  const snapshot = {
    plan: JSON.parse(JSON.stringify(plan.value)),
    icerik: JSON.parse(JSON.stringify(icerikMap.value))
  }
  try {
    const body = {
      transfers: plan.value.map(p => ({
        kaynakkoliid: p.fromId,
        hedefkoliid: p.toId,
        material: p.material,
        lotno: p.lotno,
        serino: p.serino,
        secenek: p.secenek || null,   // 🔴 kritik
        miktar: p.qty,
        kullanici: 'ahmet',
        aciklama: 'UI staged bulk'
      }))
    }
    const r = await api.post('/api/transfer/bulk_atomic', body)
    if (!r.data?.ok) throw new Error(r.data?.error || 'Bilinmeyen hata')

    const affected = new Set()
    plan.value.forEach(p => { affected.add(p.fromId); affected.add(p.toId) })
    plan.value = []
    await Promise.all([...affected].map(id => icerikYukle(id)))
    alert('Transferler kaydedildi.')
  } catch (e) {
    plan.value = snapshot.plan
    icerikMap.value = snapshot.icerik
    alert(e?.response?.data?.error || e?.message)
  }
}

/** Socket.io: canlı değişiklik */
function handleKoliChanged(payload){
  const ids = payload?.ids || []
  const toRefresh = ids.filter(id => seciliIds.value.includes(id))
  if (toRefresh.length) {
    Promise.all(toRefresh.map(id => icerikYukle(id))).catch(()=>{})
  }
}
onMounted(() => {
  loadKoliler()
  socket.on('koli:changed', handleKoliChanged)
  // arama kutusu focus ile sonuç paneli aç/kapa
  setTimeout(() => { searchOpen.value = true }, 50)
})
onBeforeUnmount(() => {
  socket.off('koli:changed', handleKoliChanged)
})
</script>

<style scoped>
.container{ max-width:1200px; margin:24px auto; padding:0 12px; }

/* Üst bar */
.bar{ display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:12px; }
.bar.sticky{
  position: sticky; top:0; background:#fff; z-index:10; padding:10px 0;
  border-bottom:1px solid #eee;
}
.bar-left{ display:flex; flex-direction:column; }
.link{ text-decoration:none; border:1px solid #ddd; padding:6px 10px; border-radius:8px; background:#fafafa; color:#111; }
.muted{ color:#6b7280; font-size:13px }
.muted.sm{ font-size:12px; color:#80868b }

/* Arama & seçim */
.selector{ display:flex; flex-direction:column; gap:10px; margin-bottom:12px; }
.lbl{ font-weight:600; margin-bottom:4px; display:block }
.searchbox{ position:static; }               /* ✅ akışta kalsın; üstüne binmesin */
.search-input{ display:flex; gap:8px; }
.search-input input{
  flex:1; padding:10px; border:1px solid #ddd; border-radius:10px;
}
.mini{ border:1px solid #ddd; border-radius:8px; padding:6px 10px; background:#f5f5f5; cursor:pointer }
.mini.primary{ background:#111827; color:#fff; border-color:#111827 }
.mini.danger{ background:#fff0f0; border-color:#f2c5c5; color:#b30000 }
.mini.outline{ background:#fff; border-color:#111827; color:#111827 }
.hint{ display:block; margin-top:4px; }

.results{
  position:static;               /* ✅ akışa sok */
  margin-top:8px;
  background:#fff;
  border:1px solid #e5e7eb;
  border-radius:12px;
  overflow:hidden;
  box-shadow: 0 10px 28px rgba(0,0,0,.08);
}
.results + .chips { margin-top: 8px; }

.results-head{
  display:flex; align-items:center; justify-content:space-between;
  padding:8px 10px; background:#f8fafc; border-bottom:1px solid #eef2f7;
}
.results-head .actions{ display:flex; align-items:center; gap:8px; }
.results-head select{ padding:4px 6px; border:1px solid #d1d5db; border-radius:6px }

.results-body{
  max-height: 320px; overflow:auto; padding:4px 10px;
}
.results .row{
  display:grid; grid-template-columns: 24px 80px 1fr auto auto; align-items:center;
  gap:8px; padding:8px 0; border-bottom:1px solid #f3f4f6; cursor:pointer;
}
.results .row:hover{ background:#fafafa }
.results .row input{ cursor:pointer }
.results .row .id{ font-weight:600 }
.results .row .code{ color:#374151 }
.results .empty{ padding:12px; text-align:center; color:#6b7280 }

/* chips + bulk paste */
.chips{ display:flex; flex-wrap:wrap; gap:8px; align-items:center; }
.chip{
  display:flex; align-items:center; gap:6px;
  border:1px solid #e5e7eb; background:#fff; border-radius:999px; padding:6px 10px;
}
.chip .x{ border:0; background:transparent; cursor:pointer; color:#666 }
.chip .strong{ font-weight:700 }
.pastebox{ display:flex; gap:6px; align-items:center; margin-left:auto }
.pastebox input{ padding:8px; border:1px solid #ddd; border-radius:8px; min-width:260px }

/* Board */
.board{ display:grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap:16px; margin-top:12px }
.col{ background:#fff; border:1px solid #eee; border-radius:12px; padding:10px; min-height:320px }
.colhead{ display:flex; justify-content:space-between; align-items:center; margin-bottom:8px }
.title{ font-weight:600; display:flex; align-items:center; gap:6px; }
.title .code{ font-weight:400; color:#555; font-size:13px }
.title .code .muted.sm { margin-left:4px; }
.col-actions{ display:flex; gap:6px }

.card{
  border:1px solid #e5e7eb; border-radius:12px; padding:10px; margin-bottom:8px;
  background:#fafafa; cursor:grab; position:relative
}
.card:active{ cursor:grabbing }
.mat{ font-weight:700 }
.meta{ margin-top:4px; display:flex; gap:6px; flex-wrap:wrap; }
.pill{ background:#eef2ff; border:1px solid #c7d2fe; border-radius:999px; padding:2px 8px; font-size:12px }
.qty{ margin-top:6px }
.delta{
  position:absolute; right:8px; top:8px; font-size:12px; padding:2px 8px;
  border-radius:999px; border:1px solid #ccc; background:#f6f6f6
}
.delta.pos{ color:#0b5; border-color:#0b5a; }
.delta.neg{ color:#c00; border-color:#c77; }

/* Staged panel */
.staged{ background:#fff; border:1px solid #eee; border-radius:12px; padding:12px; margin-top:16px }
.staged-head{ display:flex; align-items:center; justify-content:space-between; margin-bottom:8px }
.grid{ width:100%; border-collapse: collapse; }
.grid th, .grid td{ border-bottom:1px solid #eee; padding:8px; text-align:left }

/* Genel */
.alert{ margin-top:12px; padding:8px; background:#fff3cd; border:1px solid #ffeeba; color:#856404; border-radius:8px }
.tag{
  display:inline-block; padding:2px 8px; border-radius:999px; border:1px solid #e5e7eb; font-size:12px
}
.tag.draft{ background:#f3f4f6 }
.tag.sealed{ background:#ecfeff; border-color:#a5f3fc }
.tag.shipped{ background:#ecfdf5; border-color:#6ee7b7 }
.tag.cancelled{ background:#fef2f2; border-color:#fecaca }
</style>