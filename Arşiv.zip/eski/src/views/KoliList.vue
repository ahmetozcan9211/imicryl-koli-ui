<template>
  <div class="page">
    <!-- Üst bar -->
    <header class="topbar">
      <div class="left">
        <h1>Koli Listesi</h1>
        <div class="sub">Koli arayın, durumlara göre filtreleyin, yeni koli açın.</div>
      </div>
      <div class="right">
        <button class="btn" @click="$router.push('/')">← Ana Sayfa</button>
        <button class="btn primary" @click="yeniKoli">+ Yeni Koli</button>
      </div>
    </header>

    <!-- Hızlı durum filtre çipleri -->
    <div class="chips">
      <button class="chip" :class="{active: durum === ''}"      @click="setDurum('')">Hepsi</button>
      <button class="chip" :class="{active: durum === 'draft'}" @click="setDurum('draft')">Taslak</button>
      <button class="chip" :class="{active: durum === 'sealed'}" @click="setDurum('sealed')">Mühürlü</button>
      <button class="chip" :class="{active: durum === 'shipped'}" @click="setDurum('shipped')">Sevk</button>
      <button class="chip" :class="{active: durum === 'cancelled'}" @click="setDurum('cancelled')">İptal</button>
    </div>

    <!-- Arama barı -->
    <div class="toolbar">
      <input
          v-model="q"
          class="input"
          placeholder="Koli kodu / ID / Sipariş no ara…"
          @keyup.enter="load"
          @input="onSearchInput"
      />
      <button class="btn" @click="load">Ara</button>
      <button class="btn ghost" @click="temizle" :disabled="!q">Temizle</button>

      <div class="spacer"></div>

      <button class="btn ghost" @click="ping">/health test</button>
    </div>

    <!-- Yükleniyor iskeleti -->
    <div v-if="loading" class="skeleton-wrap">
      <div class="skeleton-row" v-for="i in 6" :key="i"></div>
    </div>

    <!-- Kayıtlar tablosu -->
    <div v-else>
      <div v-if="!safeKoliler.length" class="empty">
        Kayıt bulunamadı. Farklı bir arama deneyin veya <a href="#" @click.prevent="yeniKoli">yeni koli oluşturun</a>.
      </div>

      <div v-else class="table">
        <div class="thead">
          <div class="th w80">ID</div>
          <div class="th">Koli Kodu</div>
          <div class="th w120">Durum</div>
          <div class="th w160">Sipariş</div>
          <div class="th w140">Mühür (Julian)</div>
          <div class="th w180">Oluşma</div>
        </div>

        <div
            v-for="k in safeKoliler"
            :key="k.id"
            class="tr"
            @click="$router.push(`/koli/${k.id}`)"
            :title="`#${k.id} • ${k.kolikodu}`"
        >
          <div class="td w80">
            <span class="mono">#{{ k.id }}</span>
          </div>
          <div class="td">
            <div class="bold">{{ k.kolikodu }}</div>

            <div v-if="k.yerkodu" class="muted tiny">Yer: {{ k.yerkodu }}</div>
          </div>
          <div class="td w120">
            <span class="badge" :class="'st-'+(k.durum||'draft')">{{ k.durum }}</span>
          </div>
          <div class="td w160">
            <span v-if="k.siparisno" class="pill">Belge:{{ k.doctype }} {{ k.siparisno }}</span>
            <span v-else class="muted">-</span>
          </div>
          <div class="td w140">
            <span v-if="k.juliandate != null" class="mono">{{ k.juliandate }}</span>
            <span v-else class="muted">-</span>
          </div>
          <div class="td w180">
            {{ fmt(k.olusmats) }}
          </div>
        </div>
      </div>
    </div>

    <!-- Sağ alt: son test çıktısı -->
    <transition name="fade">
      <pre v-if="out" class="debug">{{ out }}</pre>
    </transition>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import api from '../api'
import { useRouter } from 'vue-router'
const router = useRouter()

const koliler = ref([])
const q = ref('')
const durum = ref('')
const out = ref('')
const loading = ref(false)
let t = null

/* ── yardımcılar ── */
function getData(res){ return res && typeof res === 'object' && 'data' in res ? res.data : res }
function fmt(ts){
  if (!ts) return '-'
  const d = new Date(ts)
  return isNaN(d.getTime()) ? String(ts) : d.toLocaleString()
}
function toKoli(obj){
  if (!obj) return null
  if (typeof obj === 'object' && 'id' in obj) return obj
  if (typeof obj === 'object') {
    const id = obj.ID ?? obj.Id ?? obj.iD ?? obj.id
    return {
      id,
      kolikodu:  obj.kolikodu ?? obj.KOLIKODU ?? obj.koliKodu ?? obj.koli_kodu ?? '',
      durum:     obj.durum ?? obj.DURUM ?? '',
      siparisno: obj.siparisno ?? obj.SIPARISNO ?? obj.siparisNo ?? null,
      olusmats:  obj.olusmats ?? obj.olusmaTs ?? obj.olusma ?? obj.created_at ?? obj.createdAt ?? null,
      yerkodu:   obj.yerkodu ?? obj.yerKodu ?? obj.YERKODU ?? null,
      juliandate: obj.juliandate ?? obj.julian ?? obj.JULIANDATE ?? null, // backend eklenince otomatik dolar
    }
  }
  return null
}
const safeKoliler = computed(() => (koliler.value || []).filter(k => k && k.id !== null && k.id !== '' && typeof k.id !== 'undefined'))

/* ── işlemler ── */
async function load(){
  loading.value = true
  try {
    const res = await api.listKoliler({ q: q.value || undefined, durum: durum.value || undefined })
    const raw = getData(res)
    const arr = Array.isArray(raw) ? raw : (Array.isArray(raw?.rows) ? raw.rows : [])
    koliler.value = arr.map(toKoli).filter(Boolean)
  } catch (e) {
    koliler.value = []
    console.error('Koli listesi yüklenemedi:', e?.response?.data || e)
  } finally {
    loading.value = false
  }
}
function onSearchInput(){
  clearTimeout(t)
  t = setTimeout(load, 300)
}
function setDurum(val){ durum.value = val; load() }
function temizle(){ q.value = ''; load() }

async function yeniKoli(){
  const kod = (prompt('Koli Kodu giriniz:', '') || '').trim()
  if (!kod) return alert('Koli kodu zorunlu')
  try {
    const res = await api.openKoli({ kolikodu: kod, olusturan: 'ahmet' })
    const data = getData(res)
    await load()
    router.push(`/koli/${data.id}`)
  } catch (e) {
    const msg = e?.response?.data?.message || e?.response?.data?.error || e?.message
    alert(msg)
  }
}
async function ping(){
  const res = await api.health()
  out.value = JSON.stringify(getData(res), null, 2)
  setTimeout(() => out.value = '', 4000)
}

onMounted(load)
</script>

<style scoped>
.page{ max-width:1100px; margin:24px auto; padding:0 10px }

/* Üst bar */
.topbar{
  display:flex; align-items:flex-start; justify-content:space-between; margin-bottom:10px
}
.topbar h1{ margin:0 0 4px 0 }
.sub{ color:#6b7280; font-size:13px }
.right{ display:flex; gap:8px }

/* Çipler */
.chips{ display:flex; gap:8px; flex-wrap:wrap; margin:8px 0 12px 0 }
.chip{
  border:1px solid #e5e7eb; background:#fff; border-radius:999px; padding:6px 10px; cursor:pointer; font-size:13px;
}
.chip.active{ background:#111827; color:#fff; border-color:#111827 }

/* Araç çubuğu */
.toolbar{ display:flex; gap:8px; align-items:center; margin-bottom:8px; flex-wrap:wrap }
.input{
  min-width:260px; padding:9px 10px; border:1px solid #e5e7eb; border-radius:10px; outline:none;
}
.input:focus{ border-color:#111827; box-shadow:0 0 0 3px rgba(17,24,39,.08) }
.spacer{ flex:1 }

/* Butonlar */
.btn{
  border:1px solid #d1d5db; background:#f9fafb; color:#111827;
  padding:8px 12px; border-radius:10px; cursor:pointer; transition:.15s ease;
}
.btn:hover{ transform: translateY(-1px) }
.btn.primary{ background:#111827; color:#fff; border-color:#111827 }
.btn.ghost{ background:#fff }

/* Tablo */
.table{ border:1px solid #e5e7eb; border-radius:12px; overflow:hidden; background:#fff }
.thead, .tr{
  display:grid; grid-template-columns: 80px 1fr 120px 160px 140px 180px; gap:10px; align-items:center;
}
.thead{ background:#f8fafc; border-bottom:1px solid #e5e7eb; font-weight:600; color:#374151; padding:10px }
.tr{ padding:10px; border-bottom:1px solid #f3f4f6; cursor:pointer }
.tr:hover{ background:#fbfbfc }
.th, .td{ overflow:hidden; text-overflow:ellipsis; white-space:nowrap }
.bold{ font-weight:600 }
.mono{ font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace; }

/* Rozetler */
.badge{
  display:inline-block; padding:4px 8px; border-radius:999px; font-size:12px; border:1px solid transparent; background:#f3f4f6; color:#111;
}
.badge.st-draft{ background:#eef2ff; color:#3730a3; border-color:#c7d2fe }
.badge.st-sealed{ background:#ecfdf5; color:#065f46; border-color:#a7f3d0 }
.badge.st-shipped{ background:#fff7ed; color:#9a3412; border-color:#fed7aa }
.badge.st-cancelled{ background:#fee2e2; color:#7f1d1d; border-color:#fecaca }

.pill{
  display:inline-block; background:#f3f4f6; border:1px solid #e5e7eb;
  border-radius:999px; padding:2px 6px; font-size:12px;
}

/* Yükleniyor iskeleti */
.skeleton-wrap{ border:1px solid #e5e7eb; border-radius:12px; overflow:hidden; background:#fff; padding:10px }
.skeleton-row{
  height:44px; margin:6px 0; background: linear-gradient(90deg, #f6f7f8 25%, #edeef1 37%, #f6f7f8 63%);
  background-size: 400% 100%; animation: shimmer 1.2s ease-in-out infinite;
  border-radius:8px;
}
@keyframes shimmer{ 0%{background-position:100% 0} 100%{background-position:-100% 0} }

/* Boş durum */
.empty{
  border:1px dashed #d1d5db; border-radius:12px; padding:20px; text-align:center; color:#6b7280; background:#fff;
}

/* Debug kutusu */
.debug{
  background:#0b1020; color:#d1e7ff; font-size:12px; padding:10px; border-radius:10px; margin-top:12px; white-space:pre-wrap
}
.fade-enter-active,.fade-leave-active{ transition: opacity .2s }
.fade-enter-from,.fade-leave-to{ opacity:0 }

/* Responsive kart görünümü (dar ekran) */
@media (max-width: 860px){
  .thead{ display:none }
  .tr{
    grid-template-columns: 1fr; gap:6px;
    border:1px solid #e5e7eb; border-radius:12px; margin:10px 0; padding:12px;
  }
  .td.w80, .td.w120, .td.w160, .td.w140, .td.w180{ width:auto }
}
</style>