<template>
  <div style="padding:24px">
    <h1>Router Çalışıyor ✅</h1>
    <p>Bu yazıyı görüyorsan <code>&lt;router-view/&gt;</code> render edildi.</p>
  </div>
</template>
