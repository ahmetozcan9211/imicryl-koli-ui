<template>
  <div>
    <nav class="nav">
      <RouterLink to="/">IMI Koli Panel</RouterLink>
      <span class="spacer"></span>
      <RouterLink to="/koliler">Koliler</RouterLink>
      <span class="spacer"></span>
      <RouterLink to="/transfer">Transfer</RouterLink>
      <RouterLink to="/siparis-koli">Siparişten Koli</RouterLink>
      <router-link to="/koli-manuel" class="mini primary">Manuel Koli</router-link>
      <router-link to="/koli-yonet" class="mini primary">Koli Yönetimi</router-link>
    </nav>

    <RouterView />
  </div>
</template>

<script setup>
import { RouterView, RouterLink } from 'vue-router'
</script>

<style>
.nav{ display:flex; gap:16px; align-items:center; padding:10px 16px; background:#111827; color:#fff }
.nav a{ color:#fff; text-decoration:none }
</style>
