import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'


export default defineConfig({
    plugins: [vue()],
    server: {
        port: 5173,
        proxy: {
            '^/api($|/)':  { target: 'http://koliapi.imicryl.server', changeOrigin: true },
            '^/api2($|/)': { target: 'http://koliapi.imicryl.server', changeOrigin: true },
            '^/api3($|/)': { target: 'http://koliapi.imicryl.server', changeOrigin: true },
            '^/api4($|/)': { target: 'http://koliapi.imicryl.server', changeOrigin: true },
        },
        strictPort: true
    }
})